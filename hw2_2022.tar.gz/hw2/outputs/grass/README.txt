- Rendered without backface culling.
- Grass model downloaded from https://sketchfab.com/3d-models/low-poly-grass-pack-5194ac6d21c242e188c2fbbe0ac122e6

